package sample

class Main {
}