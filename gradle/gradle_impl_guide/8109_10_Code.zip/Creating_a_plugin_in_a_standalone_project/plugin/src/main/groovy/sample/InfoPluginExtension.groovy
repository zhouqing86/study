package sample

class InfoPluginExtension {
    String prefix
}
