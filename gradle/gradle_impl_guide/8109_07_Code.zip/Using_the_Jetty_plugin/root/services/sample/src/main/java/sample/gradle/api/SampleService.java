package sample.gradle.api;

public interface SampleService {
    String sayHello();
}