package sample.gradle.util;

public class Logger {
    public static void log(final String message) {
        System.out.println("LOG: " + message);
    }
}