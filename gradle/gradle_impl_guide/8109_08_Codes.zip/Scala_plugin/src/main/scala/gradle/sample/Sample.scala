package gradle.sample

class Sample(val name: String) {
    def getName() = name
}
