// File: src/main/groovy/gradle/sample/Sample.groovy
package gradle.sample

import groovy.transform.ToString

@ToString
class Sample {
	String name
}